import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.IOException;

public class Adb_test {
    public static void main(String[] args) throws IOException, AWTException {
//        Runtime.getRuntime().exec("adb shell input text meniLovesMeni    h");
        Robot robot = new Robot();
        robot.delay(5000);
        robot.keyPress(KeyEvent.VK_H);
        robot.keyPress(KeyEvent.VK_I);
        robot.keyPress(KeyEvent.VK_ENTER);

        robot.mouseMove(200,400);
        robot.mousePress(InputEvent.BUTTON3_DOWN_MASK);

        robot.mouseRelease(InputEvent.BUTTON3_DOWN_MASK);




    }
}
