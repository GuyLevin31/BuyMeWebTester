package Lessons;

import com.example.JSUtils;
import netscape.javascript.JSUtil;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import java.util.concurrent.TimeUnit;

public class Lesson8d {
    private static WebDriver driver;

    @BeforeClass
    public static void Bc() {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://dgotlieb.github.io/Actions/");
    }

    @Test
    public void test(){
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        WebElement e = driver.findElement(By.xpath("/html/body/p[2]"));
        Actions action = new Actions(driver);
action.doubleClick(e);
action.build().perform();
String g = driver.findElement(By.xpath("//*[@id=\"demo\"]")).getText();
String uy = "You double clicked";
        Assert.assertEquals(g,uy);
    }
@Test
public void test01(){
    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
WebElement drag = driver.findElement(By.xpath("//*[@id=\"drag1\"]"));
WebElement drop = driver.findElement(By.xpath("//*[@id=\"div1\"]"));
    JSUtils.JavascriptDragAndDrop(driver,drag, drop);
}
@Test
public void test02(){
    Actions action2 = new Actions(driver);
    WebElement finish = driver.findElement(By.xpath("//*[@id=\"close\"]"));
    WebElement start = driver.findElement(By.xpath("/html/body/p[2]"));
    action2.moveToElement(start).moveToElement(finish).build().perform();

}
    @Test
    public void test03(){
        Actions action3 = new Actions(driver);
        WebElement one = driver.findElement(By.xpath("/html/body/form[1]/select/option[1]"));
        WebElement two = driver.findElement(By.xpath("/html/body/form[1]/select/option[2]"));
        action3.clickAndHold(one).moveToElement(two).build().perform();

    }

    @Test
    public void test04(){
//        Actions action4 = new Actions(driver);
        driver.findElement(By.name("pic")).sendKeys("C:\\Users\\guy\\Desktop\\New folder\\P1040555.JPG");
//    e.sendKeys("C:\\Users\\guy\\Desktop\\New folder\\P1040555");
//        driver.findElement(By.xpath("/html/body/form[2]/input")).sendKeys("C:\\Users\\guy\\Desktop\\New folder\\P1040555");
    }

    @Test
    public void test05() {
        Actions action5 = new Actions(driver);
        WebElement element = driver.findElement(By.xpath("//*[@id=\"clickMe\"]"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);

    }

    @Test
    public void test06() {
        Actions action6 = new Actions(driver);
        WebElement element = driver.findElement(By.xpath("//*[@id=\"clickMe\"]"));
        System.out.println(element.getLocation());
JavascriptExecutor js = (JavascriptExecutor) driver;
js.executeScript("javascript:window.scrollBy(8, 881)");
   }







    @AfterClass

    public static void Ac() {


    }


}