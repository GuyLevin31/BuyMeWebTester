package Lessons;

import com.paulhammant.ngwebdriver.NgWebDriver;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class Lesson7b {
            private static WebDriver driver1;

            @BeforeClass
//            public static void BC() {
//
//                System.out.println("BC");
//                System.setProperty("webdriver.chrome.driver", "C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe");
//                driver = new ChromeDriver();
////        driver.get("https://dgotlieb.github.io/Controllers/Controllers.html");
//                driver.get("https://translate.google.com/");

//            }
    public static void BC() {
                System.out.println("BC1");
                System.setProperty("webdriver.chrome.driver", "C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe");
                driver1 = new ChromeDriver();
//                new NgWebDriver((JavascriptExecutor)driver1).waitForAngular2RequestsToFinish();
                driver1.manage().timeouts().pageLoadTimeout(1,TimeUnit.SECONDS);

                driver1.get("https://dgotlieb.github.io/Navigation/Navigation.html");


            }



            @AfterClass

            public static void AC() {
                System.out.println("AC");
//        driver1.quit();
            }
    @Test
    public void  test01() throws InterruptedException {
        Thread.sleep(5000);

        driver1.findElement(By.id("MyAlert")).click();
        System.out.println(driver1.switchTo().alert().getText());
        driver1.switchTo().alert().accept();
    }
        @Test
        public void test02() throws InterruptedException {
            Thread.sleep(3000);

            String g = "guy";
            driver1.findElement(By.id("MyPrompt")).click();
            driver1.switchTo().alert().sendKeys("guy");

            driver1.switchTo().alert().accept();
            String f = driver1.findElement(By.id("output")).getText();
            Assert.assertEquals(g,f);
        }
@Test
         public void test03() throws InterruptedException {

    String bla = "canceled";
    Thread.sleep(3000);
    WebDriverWait wait= new WebDriverWait(driver1,5);
//    wait.until(ExpectedConditions<>)
    driver1.findElement(By.id("MyConfirm")).click();
    driver1.switchTo().alert().dismiss();
    String q = driver1.findElement(By.id("output")).getText();
    Assert.assertEquals(bla, q);
}
 @Test
 public void test04() throws InterruptedException {
     Thread.sleep(3000);

     driver1.switchTo().frame("my-frame");
     System.out.println(driver1.findElement(By.id("iframe_container")).getText());
     driver1.switchTo().defaultContent();
 }

 @Test
         public void test05() throws InterruptedException {
     Thread.sleep(3000);

     driver1.findElement(By.id("openNewTab")).click();
     ArrayList<String> s = new ArrayList<>(driver1.getWindowHandles());
     driver1.switchTo().window(s.get(0));
 }
 @Test
    public void test06() throws InterruptedException {
     Thread.sleep(3000);

     String windowBefore;
                windowBefore = driver1.getWindowHandle();
                driver1.findElement(By.xpath("//*[@id=\"contact_info_left\"]/a")).click();
                for (String nextWindow:driver1.getWindowHandles())
                    driver1.switchTo().window(windowBefore);
                }

                @Test
    public void test07(){
        WebElement w = driver1.findElement(By.id("MyPrompt"));
        Actions a = new Actions(driver1);
        a.doubleClick(driver1.findElement(By.id("MyPrompt")));
    }
 }



//        String parentWindow= driver1.getWindowHandle();
//        ArrayList <String> allWindows =new ArrayList<>(driver1.getWindowHandles()) ;
//        for(String curWindow : allWindows){
//            driver1.switchTo().window(curWindow);






                //        driver1.switchTo().window("da87c3ea-37e8-44a0-8b04-469cb821fd96");


//openNewTab






//    @Test
//    public void  test02() {
//
//        driver1.findElement(By.id("twotabsearchtextbox")).sendKeys("Leather shoes");
//        driver1.findElement(By.className("nav-input")).click();
//
//
//    }

//    @Test

//    public void  test01() {
//        String name = "Amazon.com: Online Shopping for Electronics, Apparel, Computers, Books, DVDs & more";
//        String b = driver1.getTitle();
//        Assert.assertEquals( b,name);
//
//
//    }
//    public void  test01() {
//
//            Set<Cookie> cookies = driver1.manage().getCookies();
//
//            for (Cookie cookie : cookies) {
//                System.out.println(cookie);
//
//            }
//        driver.findElement(By.id("source"));
////        bla.sendKeys("hello");
//        driver.findElement(By.className("tlid-source-text-input"));
//        driver.findElement(By.xpath("//*[@id=\"source\"]"));
//        driver.findElement(By.tagName("textarea"));
//        List<WebElement> e =

//        e.click();.




