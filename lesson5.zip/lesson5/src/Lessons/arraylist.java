package Lessons;

import java.util.ArrayList;

public class arraylist {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        list.add("hi");
        list.add("what's");
        list.add("going");
        list.add("on");

        list.set(1,"wazzzzuuuppp");
        String d=list.get(0);
        list.remove(0);

        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
//ArrayList<Lessons.mouse> mice = new ArrayList<>();
//Lessons.mouse m = new Lessons.mouse(5);
//mice.add(m);
//mice.add(new Lessons.mouse(3));
//mice.remove(m);
//System.out.println(mice.get(0).getAge());


        }


    }
    }

