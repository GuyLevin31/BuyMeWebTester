package Lessons;

import java.util.ArrayList;

public class dogmain {
    public static void main(String[] args) {
        ArrayList<dog> dogz = new ArrayList<dog>();
        dog y = new dog(6,"shlomo",3.1);
        dog z = new dog("baruch",5.1);
    dogz.add(y);
    dogz.add(z);
        System.out.println(dogz.get(0).getSize());
        dogz.remove(y);
    dogz.remove(z);
        System.out.println(dogz.get(0).getSize());

    }
    
    
    
}
