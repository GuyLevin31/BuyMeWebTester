package Lessons;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.List;

public class lesson7a {
    private static WebDriver driver;

    @BeforeClass
//    public static void BC() {
//
//
//        System.out.println("BC");
//        System.setProperty("webdriver.chrome.driver", "C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe");
//        driver = new ChromeDriver();
//        driver.get("https://translate.google.co.il/?hl=iw");
//    }

    public static void BC() {


        System.out.println("BC");
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe");
        driver = new ChromeDriver();
//        driver.get("https://dgotlieb.github.io/Controllers/Controllers.html");
        driver.get("https://translate.google.com/");

    }
    @AfterClass
    public static void AC() {
        System.out.println("AC");
//        driver1.quit();
    }

//    @Test
//    public void  test01() {
//        driver.findElement(By.id("source")).sendKeys("hello");
////        driver.findElement(By.id("gt-submit")).click();
//    }
//    @Test
//    public void  test01() {
////        driver.findElement(By.id("search")).sendKeys("wrecking ball");
//        driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr/td[@class='table5']/input[3]")).click();
//        Select mySelection = new Select(driver.findElement(By.xpath("/html/body/div/select")));
//        mySelection.selectByIndex(1);
//        List<WebElement> e = mySelection.getOptions();
//        int itemCount = e.size();
//
//        for(int l = 0; l < itemCount; l++)
//        {
//            System.out.println(e.get(l).getText());
//        }
//
//
//        }

    @Test
    public void  test01() {
//        driver.findElement(By.id("search")).sendKeys("wrecking ball");
        driver.findElement(By.xpath("//*[@id=\"email\"]")).sendKeys("levinguy21@walla.com");
        driver.findElement(By.xpath("//*[@id=\"pass\"]")).sendKeys("-");
        driver.findElement(By.xpath("//*[@id=\"u_0_2\"]")).click();





        }


    }

