package Lessons;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
    static public void bla(WebDriver driver){
        driver.findElement(By.xpath("//*[@id=\"hdr_main_links\"]/ul[1]/li[2]/a/img")).click();
    }

    static public WebElement bla1(WebDriver driver){
      WebElement e =  driver.findElement(By.xpath("//*[@id=\"hdr_main_links\"]/ul[1]/li[2]/a/img"));
        return e;
    }
}
