package Lessons;

import java.util.ArrayList;

public class c {
    public static void main(String[] args) {
        ArrayList<String> a = new ArrayList<>(3);
        a.add("hi");
        a.add("how");
        a.add("areu?");
        for (String x:a)
              {
System.out.println(a.get(1));
        }
    }
}
