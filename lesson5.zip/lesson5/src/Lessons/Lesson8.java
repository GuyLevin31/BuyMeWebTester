package Lessons;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Lesson8 {


    private static WebDriver driver1;

    @BeforeClass
    public static void BC() {
        System.out.println("BC1");
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe");
        driver1 = new ChromeDriver();
driver1.get("https://dgotlieb.github.io/WebCalculator/");

    }
    @AfterClass
    public static void AF(){
    }

//    @Test
//    public void test01(){
//        WebElement element = driver1.findElement(By.xpath("//*[@id=\"container\"]/section[5]/aside/div[2]/section[3]/section/ul/li[3]/article/a/h3/span"));
//        ((JavascriptExecutor)driver1).executeScript("arguments[0].scrollIntoView(true);",element);
//    }
   @Test
    public void test01(){
        WebElement element = driver1.findElement(By.id("seven"));
System.out.println(element.getSize());
   }
   @Test
    public void test02(){
        WebElement w = driver1.findElement(By.id("six"));
      System.out.println( w.isDisplayed());
   }
   @Test
    public void test03(){
        driver1.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        String s = "123";
driver1.findElement(By.id("one")).click();
driver1.findElement(By.id("two")).click();
driver1.findElement(By.id("three")).click();
String string= driver1.findElement(By.id("screen")).getText();
       Assert.assertEquals(s,string);
       System.out.println("Good to Go!!");

   }

}
