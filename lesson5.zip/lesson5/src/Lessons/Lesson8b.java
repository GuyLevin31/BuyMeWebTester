package Lessons;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class Lesson8b {
    private static WebDriver driver;


    @BeforeClass
    public static void BC(){
        System.setProperty("webdriver.chrome.driver","C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe");
                driver= new ChromeDriver();
        driver.get("https://dgotlieb.github.io/Selenium/synchronization.html");
    }

    @AfterClass
    public static void Ac(){
    }
    @Test
    public void test03(){
        driver.findElement(By.id("rendered")).click();
        WebDriverWait wait =new WebDriverWait(driver,10);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"finish2\"]/h4")));
        System.out.println(driver.findElement(By.xpath("//*[@id=\"finish2\"]/h4")));
    }

    @Test
    public void test01(){
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.findElement(By.xpath("//*[@id=\"btn\"]")).click();
        System.out.println(driver.findElement(By.xpath("//*[@id=\"message\"]")));
    }

    @Test
    public void test02() throws InterruptedException {
Thread.sleep(5000);
        driver.findElement(By.id("hidden")).click();
        System.out.println(driver.findElement(By.xpath("//*[@id=\"finish1\"]/h4")));

    }
}
