package Lessons;

public class d {
    public static void main(String[] args) {
        int list[]= {1,2,4,4,5,10};
        int sum=0;
double y;
        for (int i = 0; i < list.length; i++) {
            sum =sum+list[i];
        }
         y =  (double) sum/  list.length;
        System.out.println("the avarege of this list is " + y);


    }

}
