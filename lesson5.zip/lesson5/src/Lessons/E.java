package Lessons;

public class E {
    public static void main(String[] args) {
        int bla[]= {67,2,4,4,5,10};
        int sum=0;
        double y;
        for (int i = 0; i < bla.length; i++) {
            int x =sum +bla[i];
            if (x==67) {
                System.out.println("GOT YA!!");
            break;
            }
            else System.out.println("YOU ARE LUCKY!!");
        }

        }



}