package Lessons;

public class dog {
    int age;
    String name;
    double size;

    public dog(int age, String name, double size) {
        this.age = age;
        this.name = name;
        this.size = size;
    }

    public dog(String name, double size) {
        this.name = name;
        this.size = size;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSize() {
        return size;
    }

    public void setSize(double size) {
        this.size = size;
    }
}
