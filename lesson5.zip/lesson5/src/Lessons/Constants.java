package Lessons;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Constants {
//    public static final  String s = "//*[@id=\"hdr_main_links\"]/ul[1]/li[2]/a/img";
//    public static final  By s1 = By.xpath("//*[@id=\"hdr_main_links\"]/ul[1]/li[2]/a/img");
    public static final String url = "https://dgotlieb.github.io/WebCalculator/";
    public static final By six = By.id("six");
    public static final By seven = By.id("seven");
    public static final By one = By.id("one");
    public static final By multiply = By.id("multiply");
    public static final By equal = By.id("equal");
    public static final By screen = By.id("screen");
    public static final String instantDriver = "webdriver.chrome.driver";
    public static final  String path = "C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe";
    public static final  int mispar = 7;




}
