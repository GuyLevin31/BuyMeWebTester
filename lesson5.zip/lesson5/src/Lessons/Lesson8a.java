package Lessons;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.html5.Location;




public class Lesson8a {
    private static WebDriver driver1;

    @BeforeClass
    public static void BC() {
        System.out.println("BC1");
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe");
        driver1 = new ChromeDriver();
        driver1.get("https://dgotlieb.github.io/WebCalculator/");

    }
    @AfterClass
    public static void AF(){
    }


    @Test
    public void test01(){
        WebElement element = driver1.findElement(By.id("two"));
        System.out.println(element.getSize().getHeight());

    }

    @Test
    public void test02(){
        WebElement w = driver1.findElement(By.id("six"));
        System.out.println( w.getSize().getWidth());
    }

    @Test
    public void test03(){
        WebElement e = driver1.findElement(By.id("nine"));
        int g= e.getLocation().getX();
        int t= e.getLocation().getY();
Point b = new Point(g,t);
Assert.assertEquals(b,e.getLocation());
    }
}
