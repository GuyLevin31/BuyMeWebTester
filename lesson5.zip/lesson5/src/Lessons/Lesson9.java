package Lessons;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Lesson9 {
    
    private static WebDriver driver;
    @BeforeClass
    
    static public void  BC(){
        System.setProperty("webdriver.chrome.driver","C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://www.ynet.co.il/home/0,7340,L-8,00.html");
        
        
    }
    
    @AfterClass
    static public void AC(){
        
    }
    
//    @Test
//    public void test01(){
//        driver.findElement(Lessons.Constants.s1).click();
//
//    }

//    @Test
//    public void test02(){
//Lessons.LoginPage.bla(driver);
//    }

    @Test
    public void test03(){
        LoginPage.bla1(driver).click();
    }
}
