package Lessons;

import com.google.common.annotations.VisibleForTesting;
import org.junit.*;
import org.junit.rules.Timeout;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class annotations {
    private static WebDriver  driver ;
    //@Rule
//public Timeout a = Timeout.seconds(1);
    @BeforeClass
    public static void BC(){
        System.out.println("BC");
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe");
//        ChromeOptions options = new ChromeOptions();
//        options.addArguments("-incognito");
//        driver = new ChromeDriver();
        driver.get("http://www.google.co.il");
//        driver.manage().window().maximize();

    }

    @AfterClass 
    public static void AC(){
        System.out.println("AC");
//        driver.quit();


    }
    @Test
    public void test01(){
//        String url = driver.getCurrentUrl();
//        Assert.assertEquals( "https://www.google.co.il/?gws_rd=ssl",url);
//        System.out.println(driver.getCurrentUrl());
//        int a = 1;
//        int b = 1;
        System.out.println("T1");
        System.out.println(driver.getTitle());
//        System.out.println(driver.getPageSource());
//        System.out.println(driver.getWindowHandle());
//        Assert.assertEquals(a,b);

    }
//    @Test
//    public void test02(){
//        System.out.println("T2");
//
//    }
//    @Test
//    public void test03(){
//        System.out.println("T3");
//
//    }
}
