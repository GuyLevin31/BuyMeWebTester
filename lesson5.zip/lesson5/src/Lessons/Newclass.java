package Lessons;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Newclass {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
       //פקודה שמאפשרת מעבר לURL מסוים
        driver.get("http://www.google.co.il");

    }
}
