package Lessons;

import org.junit.*;
import org.junit.runners.MethodSorters;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;

import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Lesson6 {
    private static WebDriver driver ;
@BeforeClass
        public static void BC() {


    System.out.println("BC");
    System.setProperty("webdriver.chrome.driver", "C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe");
     driver = new ChromeDriver();
    driver.get("https://translate.google.co.il/?hl=iw");
//    System.out.println(driver.findElement(By.id("gt-submit")));
}


//    public static void BC1() {
//
//        System.out.println("BC1");
//        System.setProperty("webdriver.ie.driver","C:\\Users\\guy\\Desktop\\קורס אוטומציה\\IEDriverServer.exe");
//    InternetExplorerOptions options = new InternetExplorerOptions();
//    driver1 = new InternetExplorerDriver(options);
//        driver1.get("http://www.ynet.co.il");
//    driver1.navigate().refresh();
//    driver1.manage().window().maximize();
// WebElement bla;
// bla = driver1.findElement(By.linkText("כלכלה"));
//    bla.click();
//    WebElement serchbox = driver1.findElement(By.id("mainSrchBox"));
//    serchbox.sendKeys("לייקרס");
//    WebElement button;
//    button = driver1.findElement(By.id("MsBtn"));
//    button.click();
//    serchbox.submit();

//    System.out.println(driver1.findElement(By.id("BreakingNewsHP")));
//    System.out.println(driver1.findElement(By.id("element_id")));






    @AfterClass
    public static void AC() {
        System.out.println("AC");
//        driver1.quit();
    }

//    }
//    @Before
//public  void BF(){
//        System.out.println("BF");
//
//    }
//    @After
//    public void AF(){
//        System.out.println("AF");
//
//    }
    @Test
    public void  test01() {

        System.out.println(driver.findElement(By.className("tlid-source-text-input")));








//         driver.findElement(By.id("source")).sendKeys("hello");
////        bla.sendKeys("hello");
//         driver.findElement(By.id("gt-submit")).click();
//        e.click();
    }
//       WebElement z = driver.findElement(By.className("jfk-button"));
// יצירת רשימה שמקבלת וובאלמנטס שהid שלהם הוא gt=submit
//       List <WebElement> mylist = driver.findElements(By.id("gt-submit"));
//יצירת וובאלמנט מסוג כפתור שמקבל את הוובאלמנט שנמצא במקום 55 ברשימה
//       WebElement button = mylist.get(0);


//        String a = "ynet - חדשות, כלכלה, ספורט, בריאות";
//        String b = driver1.getTitle();
//        Assert.assertEquals(a, b);
//    @Test
//    public void test02(){
//    System.out.println("T1");
//System.out.println(driver1.getCurrentUrl());
//        String Lessons.c = "https://www.ynet.co.il/home/0,7340,L-8,00.html"
//                ;
//       String Lessons.d = driver1.getCurrentUrl();
//       Assert.assertEquals(Lessons.c,Lessons.d);

    }




