package Lessons;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Pom {

    public static WebDriver driver;
    @BeforeClass
    public static void Bc(){
        System.setProperty(Constants.instantDriver,Constants.path);
        driver = new ChromeDriver();
        driver.get(Constants.url);
    }

    @AfterClass
    public static void Ac() throws InterruptedException {
        Thread.sleep(5000);
        System.out.println("Done!!");
        driver.quit();
    }
    @Test
    public void test01(){
      System.out.println(driver.findElement(Constants.seven).getSize());
        System.out.println(driver.findElement(Constants.six).isDisplayed());
    }

    @Test
    public void test02(){
        int value ;
        driver.findElement(Constants.one).click();
driver.findElement(Constants.multiply).click();
driver.findElement(Constants.seven).click();
driver.findElement(Constants.equal).click();
int s = Integer.parseInt(driver.findElement(Constants.screen).getText());
        Assert.assertEquals(s,Constants.mispar);

    }
}
