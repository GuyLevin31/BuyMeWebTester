package Lessons;

public class mouse {
    private int age;

    public mouse(int age) {
        this.age = age;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
