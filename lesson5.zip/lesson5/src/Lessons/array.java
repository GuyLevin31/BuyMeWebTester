package Lessons;

public class array {
    public static void main(String[] args) {
         String s[] = {"shalom","hello","sawadika"};
        int mylist[]= new int[3];
        s[2]= "ma_kore";
        System.out.println(s[2]);
        for (int i = 0; i < s.length; i++) {
            System.out.println(s[i]);

            System.out.println("not yet...");
            
        }
        System.out.println("youre done!");
    }

}
