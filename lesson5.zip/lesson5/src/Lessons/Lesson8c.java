package Lessons;

import com.paulhammant.ngwebdriver.ByAngular;
import com.paulhammant.ngwebdriver.NgWebDriver;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.concurrent.TimeUnit;

public class Lesson8c {
    private static WebDriver driver;
    @BeforeClass
    public static void Bc(){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\guy\\Desktop\\קורס אוטומציה\\chromedriver\\chromedriver.exe");
        driver = new ChromeDriver();
        NgWebDriver driver1 = new NgWebDriver((JavascriptExecutor) driver);
        driver.get("https://dgotlieb.github.io/AngularJS/main.html");


    }
    @AfterClass
    public static void Ac(){

    }

    @Test
    public  void test01(){
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
WebElement a = driver.findElement(ByAngular.model("firstName"));
driver.findElement(ByAngular.model("firstName")).clear();
        driver.findElement(ByAngular.model("firstName")).sendKeys("guy");
        WebElement b = driver.findElement(ByAngular.model("firstName"));
        Assert.assertEquals(b.getAttribute("value"),"guy");


    }
}
