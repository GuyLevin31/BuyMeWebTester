## Extent Framework 4 - Community Edition

[![Join the chat at https://gitter.im/anshooarora/extentreports](https://badges.gitter.im/anshooarora/extentreports.svg)](https://gitter.im/anshooarora/extentreports?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
[![Maven Central](https://img.shields.io/maven-central/v/com.aventstack/extentreports.svg?maxAge=300)](http://search.maven.org/#search|ga|1|g:"com.aventstack")

This version is Java8 only.

[Klov](https://github.com/extent-framework/klov-server) report server 0.2.0 is supported with version 4.0.0+.

### Documentation

View [extentreports.com](http://extentreports.com/docs/versions/4/java/) for complete documentation.

### License

Extent Framework Community is BSD-3 licensed.